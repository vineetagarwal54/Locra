Locra diagnostics export
========================

This ZIP was created locally on your device. Nothing was uploaded anywhere;
it exists only where you saved or shared it.

It covers 2 selected conversation(s) and 19 diagnostic turn(s).

Included files:
  - transcript.md    Readable transcript of the selected conversation(s).
  - diagnostics.json  Structured data: response attempts, inference timings,
                      context-selection diagnostics, and app / build / model /
                      database versions plus model, storage, and recent-error state.
  - README.txt        This file.

Excluded by design:
  - Images, model files, and audio.
  - Secrets, tokens, and absolute local file paths (redacted).
  - Personally identifying device identifiers.

Selected conversation text and response attempts may still contain personal
information you typed. Review the contents before sharing this ZIP with anyone.
